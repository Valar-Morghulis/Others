//
//  BaseViewController.h
//  MacChatty
//
//  Created by kesalin on 9/14/11.
//  Copyright 2011 kesalin@gmail.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BaseViewController : NSViewController {
@private
}

- (void) activate;

@end
