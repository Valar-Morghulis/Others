#import <UIKit/UIKit.h>

@interface ExampleAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic) UIWindow *window;
@end
